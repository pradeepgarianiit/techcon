/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class LoginDAO 
{
    Connection conn;
   public LoginDAO()throws Exception
   {
       Context ctx=new InitialContext();
       DataSource ds=(DataSource)ctx.lookup("jdbc/myData");
        conn=ds.getConnection();
       
       }
   public String checkLogin(String uid,String password)throws Exception
   {
       
     
       PreparedStatement psmt=conn.prepareStatement("select * from Admin1.User1 where username=? and password=?");
       psmt.setString(1, uid);
       psmt.setString(2, password);
       ResultSet rs=psmt.executeQuery();
       
       String loginname="";
       if(rs.next())
       {
          loginname=rs.getString(3);
          
      }  
      
       else
      {
          loginname="Error";
      }
      
        return loginname.trim();
   }
   }


